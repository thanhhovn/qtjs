Papyros Backers
===============

Papyros is supported by the following contributors on our [Bountysource Salt campaign](https://salt.bountysource.com/teams/papyros):

* Hoang Anh
* Graham Steffaniak
* Christine Noblejas
* yaccin
* tobyx
* sonph
* David Smit
* mnitpro
* Louis-Philippe Fortin
* And several anonymous sponsors